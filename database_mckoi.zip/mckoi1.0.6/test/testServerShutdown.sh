#!/bin/sh

java -cp ../mckoidb.jar:../gnu-regexp-1.0.8.jar com.mckoi.runtime.McKoiDBMain -shutdown test test
