
Documentation is available here;

http://www.mckoi.com/database/

